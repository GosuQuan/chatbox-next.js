-- 创建新数据库
CREATE DATABASE IF NOT EXISTS chatbox_db;

-- 使用新数据库
USE chatbox_db;

-- 刷新权限
FLUSH PRIVILEGES;
